import tkinter as tk

root = tk.Tk()

v = tk.IntVar()
v.set(1)  # initializing the choice, i.e. Python

languages = [("Python", 101),
             ("Perl", 102),
             ("Java", 103),
             ("C++", 104),
             ("C", 105)]


def showChoice():
    print(v.get())
    print(v.get())


tk.Label(root,
         text="""Choose your favourite 
programming language:""",
         justify=tk.LEFT,
         padx=20).pack()

for language, val in languages:
    tk.Radiobutton(root,
                   text=language,
                   indicatoron=0,
                   width=100,
                   padx=100,
                   variable=v,
                   command=showChoice,
                   value=val).pack(anchor=tk.W)

# pass

root.mainloop()
