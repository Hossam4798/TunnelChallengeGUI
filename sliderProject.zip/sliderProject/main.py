import tkinter as tk


class App:
    def __init__(self):
        self.root = tk.Tk()
        self._job = None
        self.slider1 = tk.Scale(self.root, from_=0, to=42, command=self.update)
        self.slider1.set(20)
        self.slider1.pack()
        self.slider2 = tk.Scale(self.root, from_=0, to=200, orient=tk.HORIZONTAL, command=self.update)
        self.slider2.set(25)
        self.slider2.pack()

        self.root.mainloop()

    def show_values(self):
        self._job = None
        print(self.slider1.get(), self.slider2.get())

    def update(self, event):
        if self._job:
            self.root.after_cancel(self._job)
        self._job = self.root.after(10, self.show_values())


app = App()
